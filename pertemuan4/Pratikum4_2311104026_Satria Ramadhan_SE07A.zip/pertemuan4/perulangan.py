# for i in range (5):
#     print("Hello World")
        
# count = 5
# for i in range (10):
#     print(count)
#     count += 5

# i = 5
# for i in range (2, 10):
#     print(i)

# i = 3
# for t in range (20):
#     i = i+5
#     print(i)
