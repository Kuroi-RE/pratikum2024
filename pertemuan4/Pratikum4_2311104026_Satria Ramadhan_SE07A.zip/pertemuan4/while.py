# angka = 4
# while angka < 10:
#     print(angka)  
#     angka += 1   


# quota = -3
# while(quota < -1):
#     print("Kuota ")
#     quota = quota-1

quota = -1

while(True):
    print("MEWING")
    quota = quota-1

    if  (quota < 0):
        break