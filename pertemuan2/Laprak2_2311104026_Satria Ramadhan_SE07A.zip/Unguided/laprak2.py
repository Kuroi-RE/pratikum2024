# Nama : Satria Ramadhan
# Nim : 2311104026
# Kelas : S1-SE07A

# Program output dari variabel
myVariabel = "Satria Ramadhan suka belajar pemrograman dengan bahasa python" # variabel untuk menampung nilai

print(myVariabel) # memunculkan variabel ke Terminal

# Program Volume Balok
panjang = 8
lebar = 5
tinggi = 6

Volume_Balok = panjang * lebar * tinggi # perhitungan sesuai rumus

print("Volume balok: ", Volume_Balok) # Munculkan hasil ke terminal

# Program Keliling lingkaran dengan nilai dari inputan user
π = 3.14
r = int(input("Masukan jari-jari: "))

keliling_lingkaran = 2 * π * r # hitung sesuai rumus


print("Keliling lingkaran: ", keliling_lingkaran) # munculkan hasil ke terminal