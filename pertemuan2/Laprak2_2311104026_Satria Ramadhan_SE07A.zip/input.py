nama = input("Nama: ")
print("Nama saya "+ nama)

kampus = input("Kampusmu = ")
jurusan = input("Jurusanmu = ")

print(f"Kampusmu adalah {kampus} dan Jurusanmu adalah {jurusan}")


panjang = int(input("Masukan panjang: "))
lebar = int(input("Masukan lebar: "))

luas = panjang * lebar

print(f"Luas : {luas}")