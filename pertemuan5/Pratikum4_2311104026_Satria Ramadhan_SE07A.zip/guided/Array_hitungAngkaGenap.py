angka_genap = []

for i in range (1, 10):

    
    if  i % 2 == 0:
        angka_genap.append(i)

print(angka_genap)