angka = [1, 2, 3, 4, 5]
text = ["satu", "dua", "tiga", "empat", "lima"]

# print(angka)
# print(text)

# # adding new data to array
# text.append("enam") 

# [pop] to remove some data with index
text.pop(0)

# [remove] to remove some data with specific string
text.remove("dua")


print(text)


# output spesific data
nilai = text[3]


print(nilai)


# Looping
for x in text:
    print(x)

