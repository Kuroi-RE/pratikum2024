buah = [
    ["apel", "mangga", "jeruk"],
    [1,2,3,4,5]
    ]

# for x in range(len(buah)):


#     for y in range(len(buah[x])):
#         print(buah[x][y])

panjang = len(buah)
print(panjang)