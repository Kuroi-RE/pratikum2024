bilangan = int(input("Masukan Bilangan: "))

if (bilangan %2 == 1):
    print("Bilangan Ganjil")
elif(bilangan == 0):
    print("Bilangan 0")
else:
    print("Bilangan Genap")